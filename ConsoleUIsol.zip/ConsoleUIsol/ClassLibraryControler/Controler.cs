﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryControler
{
    public class Controler
    {
        //Create middle tier:


        //Validate method, throw exceptions if bad
        //Validate name, at least 4 but not longer than 20 characters
        //Validate zip is at least 5 characters
        // pass good data to data tier with call to SaveNewPermit(username, zip)
        //will return a false if failed to save, then
        // throw exception database full or other database issue

        //public static string[,] GetPermitsMT(string pPW)  // if bad PW throw exception
        // else call data tier to get data and return it
        static public void CheckAndEnterData(string[] elementsToCheck)
        {
            throw new NotImplementedException();
        }
    }
}
