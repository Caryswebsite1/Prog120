﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitLib
{
    public class Banana : Fruit
    {
        public Banana(int nDayBought)
        {
            Name = "Banana";
            DayBought = nDayBought;
            RotDays = 4;
        }

        // Banana Print
        public override void print()
        {
            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("{0} ", Name);
            Console.ResetColor();
        }// end print for Banana

    }// end class Banana
}// end namespace
