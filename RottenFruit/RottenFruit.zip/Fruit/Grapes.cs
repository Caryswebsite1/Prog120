﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitLib
{
    public class Grapes : Fruit
    {
        public Grapes(int nDayBought)
        {
            Name = "Grapes";
            DayBought = nDayBought;
            RotDays = 3;
        }

        // Grapes Print
        public override void print()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("{0} ", Name);
            Console.ResetColor();
        }// end print for Grapes

    }// end class Grapes
}// end namespace
