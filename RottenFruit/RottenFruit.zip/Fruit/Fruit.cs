﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitLib
{
    
    //******************  Fruit Class ************************************
    //  virtual fruit base class for fruit types
    // ********************************************************************
    public class Fruit
    {
        private string s_Name;  // name of the fruit type (ie apple, grape, bananna etc.

        public string Name
        {
            get { return s_Name; }
            set { s_Name = value; }
        }

        private int n_RotDays;  // number of days fruit takes to rot.

        public int RotDays
        {
            get { return n_RotDays; }
            set { n_RotDays = value; }
        }

        private int n_DayBought;  // day the fruit was bought.

        public int DayBought
        {
            get { return n_DayBought; }
            set { n_DayBought = value; }
        }

        public virtual void print()
        {
            Console.WriteLine("Fruit Base Class Here.");
        }


        // Edible checks if number of days since the day bought is 
        // greater than or equal to the days required for the fruit to 
        // rot.  Returns true if edible, false if rotten.
        public bool Edible(int nCurrentDay)
        {
            bool bEdible = true;

            if( RotDays <= (nCurrentDay - DayBought) )
            {
                bEdible = false;
            }

            return bEdible;
        }// end Edible


    }// end virtual Fruit


}// end namespace fruit
