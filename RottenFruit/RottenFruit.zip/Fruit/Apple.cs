﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitLib
{
    public class Apple : Fruit
    {
        public Apple(int nDayBought)
        {
            Name = "Apple";
            DayBought = nDayBought;
            RotDays = 6;
        }

        // Apple Print
        public override void print()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("{0} ", Name);
            Console.ResetColor();

        }// end print for Apple

    }// end class Apple
}// end namespace
