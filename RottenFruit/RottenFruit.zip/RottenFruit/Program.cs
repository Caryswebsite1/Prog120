﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FruitLib;


namespace RottenFruit
{
    class Program
    {
        static void Main(string[] args)
        {
            int nCurrentDay = 1;  // starting day
            List<Fruit> FruitBowl = new List<Fruit>();  // fruitbowl (list of fruit)

            // set up initial fruit and fruit bowl
            Apple apple1 = new Apple(nCurrentDay);
            Apple apple2 = new Apple(nCurrentDay);
            Apple apple3 = new Apple(nCurrentDay);
            Banana banana1 = new Banana(nCurrentDay);
            Banana banana2 = new Banana(nCurrentDay);
            Banana banana3 = new Banana(nCurrentDay);
            Grapes grape1 = new Grapes(nCurrentDay);


            // add to list
            FruitBowl.Add(apple1);
            FruitBowl.Add(banana1);
            FruitBowl.Add(apple2);
            FruitBowl.Add(grape1);
            FruitBowl.Add(apple3);
            FruitBowl.Add(banana2);
            FruitBowl.Add(banana3);

            //13 day loop
            for(nCurrentDay = 1; nCurrentDay < 14; nCurrentDay++)
            {
                // check for rot.
                FruitBowl = RotCheck(FruitBowl, nCurrentDay);

                // write out contents of fruit bowl for the day.
                Console.WriteLine(""); // blank line to help space things out
            
                Console.WriteLine("This is day " + nCurrentDay + ":");

                // if day 6, buy more fruit.
                if (nCurrentDay == 6)
                {
                    Grapes newGrape = new Grapes(nCurrentDay);
                    Apple newApple = new Apple(nCurrentDay);
                    Banana newBanana = new Banana(nCurrentDay);

                    FruitBowl.Add(newGrape);
                    FruitBowl.Add(newApple);
                    FruitBowl.Add(newBanana);
                }// end if day 6

                if (FruitBowl.Count > 0) // if there is fruit in the bowl the print it out.
                {
                    Console.WriteLine("In our fruit bowl, we have:");

                    foreach (Fruit theFruit in FruitBowl)
                    {
                        theFruit.print();
                    }
                }// end if there is fruit in bowl
                else
                {
                    // bowl is empty!!
                    Console.WriteLine("Your fruit bowl is empty.");
                }// end if fruitbowl

            }// end for ncurrentDay

            Console.ReadLine();  // readline at end so we can see our console output.

        }// end Main


        // ----------------------------------------------------------------------------------
        // RotCheck:  
        // Called By Main
        // Checks to see if fruit in passed in fruitbowl is rotten based on day passed in.
        // If so, it deletes that fruit from the fruitbowl. 
        //-------------------------------------------------------------------------------------
        public static List<Fruit> RotCheck(List<Fruit> theFruitBowl, int nDay)
        {
            List<Fruit> tempBowl = new List<Fruit>();  // temp bowl of fruit

            foreach(Fruit theFruit in theFruitBowl)
            {
                // for each fruit in the fruit bowl, check if it is rotten.
                // if not, put into the temp bowl
                if (theFruit.Edible(nDay))
                {
                    // fruit still good add to temp.
                    tempBowl.Add(theFruit);
                }// end if
                    
            }// end foreach

            // ok, tempBowl has the good fruit. 
            // because C# has automatic garbage collection, we don't need to specifically delete
            // any object we create.  We could just hang them out to dry.
            
            return tempBowl;  // return the new fruitbowl

        }// end RotCheck






    }// end class program
}// namespace RottenFruit
