﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    public enum Suit
    {
        Club = 1,
        Diamond,
        Heart,
        Spade
    }

    public enum Rank
    {
        Deuce = 2,
        Three = 3,
        Four =4,
        Five = 5,
        Six = 6,
        Seven = 7,
        Eight = 8,
        Nine = 9,
        Ten = 10,
        Jack = 11,
        Queen = 12,
        King = 13,
        Ace = 14
    }

    public abstract class SuperCard : IComparable<SuperCard>, IEquatable<SuperCard>
    {
        // available for children
        public Rank CardRank { get; set; }

        // must be overriden by children
        public abstract Suit CardSuit { get; set; }

        private bool _inPlay = false;

        public bool InPlay
        {
            get { return _inPlay; }
            set { _inPlay = value; }
        }


        // -------------------------------------------------------------------
        // CompareTo:  called by Array.Sort, required by IComparable interface
        //---------------------------------------------------------------------
        public int CompareTo(SuperCard other)
        {
            int nReturnValue = 0;

            if (this.CardSuit > other.CardSuit)
            {
                nReturnValue = 1;  // this is bigger suite
            }
            else if(this.CardSuit < other.CardSuit)
            {
                nReturnValue = -1; // this is smaller suite
            }
            else // they are the same suite...
            {
                if (this.CardRank > other.CardRank)
                {
                    nReturnValue = 1;  // this is bigger rank
                }
                else if (this.CardRank < other.CardRank)
                {
                    nReturnValue = -1; // this is smaller rank
                }
                else
                {
                    // they are also the same rank
                    nReturnValue = 0;
                }// end else same rank

            }// end else same suite

            return nReturnValue;
        }// end CompareTo


        //--------------------------------------------------------------
        // Display()
        // To be overriden by children
        // Expected to display cards in some way.
        // ---------------------------------------------------------------
        public abstract void Display();



        //--------------------------------------------------------------
        // Equals(SuperCard other)
        // Implementation of IEquatable interface
        // check if the card passed in is of the same suit as this card.
        // Returns true is so, false otherwise.
        // ---------------------------------------------------------------
        public bool Equals(SuperCard other)
        {
            // this is the short version:  return (this.CardSuit == other.CardSuit);

            // doing the long version:
            bool bReturn = false;
            if(this.CardSuit == other.CardSuit)
            {
                bReturn = true;
            }
            return bReturn;
        }// end Equals


    }// end class SuperCard

}// end namespace CardLibrary
