﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{

    // The 4 card classes are in this file.

    // -------------------------------------------------------------------
    // CardClub Class:
    // --------------------------------------------------------------------
    public class CardClub : SuperCard
    {
        // The "suit" of these cards:  Override the abstract in the superclass.
        private Suit _CardSuit = Suit.Club;

        public override Suit CardSuit
        {
            get { return _CardSuit; }
            set { _CardSuit = value; }
        }// end cardsuit override

        // constructor
        public CardClub(Rank inRank)
        {
            CardRank = inRank;
        }


        //--------------------------------------------------------------
        // Display()
        // print out this card
        // ---------------------------------------------------------------
        public override void Display()
        {
            // Code to Display a club card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(CardRank + " of " + CardSuit + "s ♣");
            Console.ResetColor();
        }// end Display


    }// end class CardClub


    // CardDiamond Class: 
    // --------------------------------------------------------------------
    public class CardDiamond : SuperCard
    {
        // The "suit" of these cards:  Override the abstract in the superclass.
        private Suit _CardSuit = Suit.Diamond;

        public override Suit CardSuit
        {
            get { return _CardSuit; }
            set { _CardSuit = value; }
        }// end cardsuit override

        // constructor
        public CardDiamond(Rank inRank)
        {
            CardRank = inRank;
        }


        //--------------------------------------------------------------
        // Display()
        // print out this card
        // ---------------------------------------------------------------
        public override void Display()
        {
            // Code to Display a diamond card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine(CardRank + " of " + CardSuit + "s ♦");
            Console.ResetColor();

        }// end Display


    }// end class CardDiamond


    // CardHeart Class: 
    // --------------------------------------------------------------------
    public class CardHeart : SuperCard
    {
        // The "suit" of these cards:  Override the abstract in the superclass.
        private Suit _CardSuit = Suit.Heart;

        public override Suit CardSuit
        {
            get { return _CardSuit; }
            set { _CardSuit = value; }
        }// end cardsuit override

        // constructor
        public CardHeart(Rank inRank)
        {
            CardRank = inRank;
        }


        //--------------------------------------------------------------
        // Display()
        // print out this card
        // ---------------------------------------------------------------
        public override void Display()
        {
            // Code to Display a heart card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(CardRank + " of " + CardSuit + "s ♥");
            Console.ResetColor();
        }// end Display


    }// end class CardHeart


    // CardSpade Class: 
    // --------------------------------------------------------------------
    public class CardSpade : SuperCard
    {
        // The "suit" of these cards:  Override the abstract in the superclass.
        private Suit _CardSuit = Suit.Spade;

        public override Suit CardSuit
        {
            get { return _CardSuit; }
            set { _CardSuit = value; }
        }// end cardsuit override

        // constructor
        public CardSpade(Rank inRank)
        {
            CardRank = inRank;
        }


        //--------------------------------------------------------------
        // Display()
        // print out this card
        // ---------------------------------------------------------------
        public override void Display()
        {
            // Code to Display a Spade card...
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine(CardRank + " of " + CardSuit + "s ♠");
            Console.ResetColor();
        }// end Display


    }// end class CardSpade


}// end namespace CardLibrary


