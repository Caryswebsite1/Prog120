﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardLibrary;

namespace PokerProject
{
    class Program
    {

        static void Main(string[] args)
        {
            CardSet myDeck = new CardSet();

            // set up number of cards per hand and initial player balance
            int howManyCards = 5;
            int balance = 10;


            // set up game console colors:
            SetMainGameColors();

            Console.Clear();  // clears anything on screen and sets up background color for whole screen.

            // initial greeting:
            Console.WriteLine("Welcome to the Poker game.");
            Console.WriteLine("You have $10 and each bet will be $1.");
            Console.WriteLine("Press 'Enter' when you are ready to start.");
            
            Console.ReadLine(); // wait for key press.

            // game loop
            while (balance > 0)
            {
                // reset the cards to be all available.
                myDeck.ResetUsage();

                // deal the cards to each player
                SuperCard[] computerHand = myDeck.GetCards(howManyCards);
                SuperCard[] playersHand = myDeck.GetCards(howManyCards);

                // sort the cards.
                Array.Sort(computerHand);  
                Array.Sort(playersHand); 



                // display the hands
                DisplayHands(computerHand, playersHand);

                // determine if player won
                bool won = CompareHands(computerHand, playersHand);

                if (won)
                {
                    balance += 1;
                    Console.WriteLine("You Won!  Your new balance is: {0}", balance);
                }
                else
                {
                    balance -= 1;
                    Console.WriteLine("Oh No! You Lost!  Your new balance is: {0}", balance);
                }

                if(balance > 0)  // player still has money
                {
                    Console.WriteLine("Please hit 'Enter' for another hand.");
                }
                else // that's it. game over.
                {
                    Console.WriteLine(); // get some space before game over statment so it stands out a bit.
                    Console.WriteLine();
                    Console.WriteLine("ALAS!  You are out of money!  Game Over.");
                }
                
                Console.WriteLine(); // get some space before next hand.
                Console.WriteLine();
                Console.WriteLine();
                Console.ReadLine();   // wait for player action.

                // clear screen for next hand:
                Console.Clear();
            }// end while loop


        }// end of main


        //--------------------------------------------------------------
        // SetMainGameColors()
        // Set the main console colors.  These get reset by card displays
        // so we need to be able to reset them.
        // ---------------------------------------------------------------
        private static void SetMainGameColors()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
        }// end SetMainGameColors


        //--------------------------------------------------------------
        // DisplayHands()
        // Display the computer and player hands.
        // ---------------------------------------------------------------
        private static void DisplayHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            SetMainGameColors();  // make sure we have correct game colors for next statement
            Console.WriteLine("This is the Computer's Hand:");
            foreach (SuperCard aCard in computerHand)
            {
                aCard.Display();
            }

            SetMainGameColors();  // reset game colors for next statement
            Console.WriteLine(); // get a couple of lines of space.
            Console.WriteLine();
            Console.WriteLine("This is the Player's Hand:");
            foreach (SuperCard aCard in playersHand)
            {
                aCard.Display();
            }

            SetMainGameColors();  // reset game colors
        }// end DisplayHands


        //--------------------------------------------------------------
        // CompareHands()
        // compare the computer's and player's hands of cards.  Currently 
        // if the player's hand card values sum to a total that is higher
        // than the computer's then the player is the winner.
        // 
        // Returns:  a bool indicating if the player won or not.
        // ---------------------------------------------------------------
        private static bool CompareHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            bool bPlayerWon = false;
            int cTotal = 0;
            int pTotal = 0;

            foreach (SuperCard aCard in computerHand)
            {
                cTotal += (int)aCard.CardRank;
            }

            foreach (SuperCard aCard in playersHand)
            {
                pTotal += (int)aCard.CardRank;
            }

            if(pTotal > cTotal)
            {
                bPlayerWon = true;
            }

            return bPlayerWon;
        }// end CompareHands



    } // end of class program
}// end of namespace
