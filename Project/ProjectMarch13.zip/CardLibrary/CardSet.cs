﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardLibrary
{
    //-------------------------------------------------------------------------
    // CardSet:  Holds a deck and card manipulation methods
    //-------------------------------------------------------------------------
    public class CardSet
    {
        public SuperCard[] cardArray;   // the deck of cards
        private Random rand = new Random();

        private int nDeckSize = 52;  // size of a deck;

        public CardSet()
        {
            // create actual cardArray
            cardArray = new SuperCard[nDeckSize];

            // filling the deck:
            // Since we do NOT have a constructor that can take a Suit and make the 
            // correct card type, we have to create each Suit.
            // we could do a set of nested loops but we can also do it all in one loop.
            Rank myRank = Rank.Deuce;  // using Rank as a loop iterator.

            for (myRank = Rank.Deuce; myRank <= Rank.Ace; myRank++)
            {
                // create a card of each suit in the current rank and add to the array
                // at the appropriate location.  Remember we are going to use from index 0 to 51
                // We could just bypass the card varibles but I like to have them for debug and clarity.
                CardClub myClub = new CardClub(myRank);
                CardDiamond myDiamond = new CardDiamond(myRank);
                CardHeart myHeart = new CardHeart(myRank);
                CardSpade mySpade = new CardSpade(myRank);

                // add each card to the apropriate place in the array...
                cardArray[((int)myRank - 2)] = myClub; // clubs start at 0 and end at 12...
                cardArray[((int)myRank + 11)] = myDiamond;   // Diamonds start at 13 and end at 25...
                cardArray[((int)myRank + 24)] = myHeart;  // Hearts start at 26 and end at 38...
                cardArray[((int)myRank + 37)] = mySpade;  // Spades start at 39 and end at 51...

            }// end for myRank

        }// end constructor CardSet


        //--------------------------------------------------------
        // ResetCardset
        //-------------------------------------------------------
        public void ResetUsage()
        {
            int i = 0;
            for(i=0; i< nDeckSize; i++)
            {
                cardArray[i].InPlay = false;
            }

        }// end ResetUsage



        // -------------------------------------------------------------
        // GetCards(int)
        //
        // Provides a random array set of 'int' number of cards.
        //----------------------------------------------------------------
        public SuperCard[] GetCards(int number)
        {
            SuperCard[] hand = new SuperCard[number];

            int count = 0;
            // while our good card count is less than the number required..
            while (count < hand.Length)
            {
                hand[count] = cardArray[rand.Next(cardArray.Length)];
                if (!hand[count].InPlay)
                {
                    // good card.  Set inplay and up count.
                    hand[count].InPlay = true;
                    count += 1;
                }// end if good card

                // if not a good card, count doesn't get incremented so we go around again for that slot.
            }// end while.

            /*  OLD CODE 
            for(int i = 0; i< hand.Length; i++)
            {
                hand[i] = cardArray[rand.Next(cardArray.Length)];
            }
            */

            return hand;
        }// end GetCards



        // -------------------------------------------------------------
        // GetOneCard()
        //
        // Provides a random card from the current deck.
        //----------------------------------------------------------------
        public SuperCard GetOneCard()
        {
            // just call getcards then take the card from the array.

            SuperCard[] getArrayOfOne = GetCards(1);
            SuperCard oneCard = getArrayOfOne[0];

            return oneCard;
        } // end GetOneCard

    }// end class CardSet


}// end namespace CardLibrary
