﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CardLibrary;

namespace PokerProject
{
    class Program
    {

        static void Main(string[] args)
        {
            CardSet myDeck = new CardSet();

            // set up number of cards per hand and initial player balance
            int howManyCards = 5;
            int balance = 10;


            // set up game console colors:
            SetMainGameColors();

            Console.Clear();  // clears anything on screen and sets up background color for whole screen.

            // initial greeting:
            Console.WriteLine("Welcome to the Poker game.");
            Console.WriteLine("You have $10 and each bet will be $1.");
            Console.WriteLine("Highest card total wins.  A flush always wins.  House wins ties.");
            Console.WriteLine("Press 'Enter' when you are ready to start.");
            
            Console.ReadLine(); // wait for key press.

            // game loop
            while (balance > 0)
            {
                // reset the cards to be all available.
                myDeck.ResetUsage();

                // deal the cards to each player
                SuperCard[] computerHand = myDeck.GetCards(howManyCards);
                SuperCard[] playersHand = myDeck.GetCards(howManyCards);

                // sort the cards.
                Array.Sort(computerHand);  
                Array.Sort(playersHand); 



                // display the hands
                DisplayHands(computerHand, playersHand);

                // check if player wants to replace a card
                PlayerDrawsOne(playersHand, myDeck);

                // computer checks to draw a card:
                ComputerDrawsOne(computerHand, myDeck);

                // resort and re display
                Array.Sort(computerHand);
                Array.Sort(playersHand);
                DisplayHands(computerHand, playersHand);


                // determine if player won
                bool won = CompareHands(computerHand, playersHand);

                if (won)
                {
                    balance += 1;
                    Console.WriteLine("You Won!  Your new balance is: {0}", balance);
                }
                else
                {
                    balance -= 1;
                    Console.WriteLine("Oh No! You Lost!  Your new balance is: {0}", balance);
                }

                if(balance > 0)  // player still has money
                {
                    Console.WriteLine("Please hit 'Enter' for another hand.");
                }
                else // that's it. game over.
                {
                    Console.WriteLine(); // get some space before game over statment so it stands out a bit.
                    Console.WriteLine();
                    Console.WriteLine("ALAS!  You are out of money!  Game Over.");
                }
                
                Console.WriteLine(); // get some space before next hand.
                Console.WriteLine();
                Console.WriteLine();
                Console.ReadLine();   // wait for player action.

                // clear screen for next hand:
                Console.Clear();
            }// end while loop


        }// end of main



        //--------------------------------------------------------------
        // ComputerDrawsOne(SuperCard[] computerHand, CardSet myDeck)
        // 
        // Forces computer to draw a new card if any card is below 8
        // but NOT if computer has a flush.
        // ---------------------------------------------------------------
        private static void ComputerDrawsOne(SuperCard[] computerHand, CardSet myDeck)
        {
            // first check for a flush
            Suit mainSuit = computerHand[0].CardSuit;
            bool bFlush = true;
            int nLowestCardIndex = 0;

            int i = 0;
            for(i = 0; i< computerHand.Length; i++)
            {
                // finding lowest card index along the way.
                if(computerHand[i].CardRank < computerHand[nLowestCardIndex].CardRank)
                {
                    // current card is smaller. so update index
                    nLowestCardIndex = i;
                }

                // check suite for flush
                if(computerHand[i].CardSuit != mainSuit)
                {
                    bFlush = false;
                }
            }// end for

            // if bFlush is still == true here then we have a flush!

            if (!bFlush)
            {
                // no Flush so get lowest card in hand, if it is 7 or less, get a new card.
                // already have lowest card from nLowestCardIndex !
                if(computerHand[nLowestCardIndex].CardRank <= Rank.Seven)
                {
                    // computer draws a card
                    SuperCard newCard = myDeck.GetOneCard();
                    computerHand[nLowestCardIndex] = newCard;
                }
            }// end if not a flush

        }// end computer draws one.


        //--------------------------------------------------------------
        // PlayerDrawsOne(SuperCard[] playersHand, CardSet myDeck)
        // Asks player if they want to replace a card.  If the response is not 0
        // and < 6 then that card is replaced with a new card from the deck.
        // 
        // ---------------------------------------------------------------
        private static void PlayerDrawsOne(SuperCard[] playersHand, CardSet myDeck)
        {
            String playerInput = "";
            int cardNum = -1;
            bool bGoodInput = false;
            // force user to input good data.  drop into while loop
            while (!bGoodInput)
            {
                Console.WriteLine("If you wish to replace a card, please enter a number up to your hand size.");
                Console.WriteLine("A zero will mean you don't want to replace any.");

                playerInput = Console.ReadLine(); // wait for player input

                try  // player might have entered garbage so we do the try in case this throws..
                {
                    cardNum = Convert.ToInt16(playerInput);
                }
                catch
                {
                    // set cardNum back to -1.  bad input!
                    cardNum = -1;
                }

                if (cardNum > 0 && cardNum < (playersHand.Length + 1))
                {
                    // wants a new card:
                    bGoodInput = true;
                    SuperCard newCard = myDeck.GetOneCard();
                    playersHand[cardNum - 1] = newCard;
                }
                else if(cardNum == 0)
                {
                    // no card wanted.
                    bGoodInput = true;
                }
            }// end while !bGoodInput


        }// end PlayerDrawsOne




        //--------------------------------------------------------------
        // SetMainGameColors()
        // Set the main console colors.  These get reset by card displays
        // so we need to be able to reset them.
        // ---------------------------------------------------------------
        private static void SetMainGameColors()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
        }// end SetMainGameColors


        //--------------------------------------------------------------
        // DisplayHands()
        // Display the computer and player hands.
        // ---------------------------------------------------------------
        private static void DisplayHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            SetMainGameColors();  // make sure we have correct game colors for next statement
            Console.WriteLine("This is the Computer's Hand:");
            foreach (SuperCard aCard in computerHand)
            {
                aCard.Display();
            }

            SetMainGameColors();  // reset game colors for next statement
            Console.WriteLine(); // get a couple of lines of space.
            Console.WriteLine();
            Console.WriteLine("This is the Player's Hand:");
            foreach (SuperCard aCard in playersHand)
            {
                aCard.Display();
            }

            SetMainGameColors();  // reset game colors
        }// end DisplayHands


        //--------------------------------------------------------------
        // CompareHands()
        // compare the computer's and player's hands of cards.  Currently 
        // if the player's hand card values sum to a total that is higher
        // than the computer's then the player is the winner.
        // 
        // Returns:  a bool indicating if the player won or not.
        // ---------------------------------------------------------------
        private static bool CompareHands(SuperCard[] computerHand, SuperCard[] playersHand)
        {
            bool bPlayerWon = false;
            int cTotal = 0;
            int pTotal = 0;

            foreach (SuperCard aCard in computerHand)
            {
                cTotal += (int)aCard.CardRank;
            }

            foreach (SuperCard aCard in playersHand)
            {
                pTotal += (int)aCard.CardRank;
            }

            if(pTotal > cTotal)
            {
                bPlayerWon = true;
            }

            return bPlayerWon;
        }// end CompareHands



    } // end of class program
}// end of namespace
