﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModelLibrary
{
    public static class DataModel
    {
        private static string[,] fakeDB = new string[10, 3];

        public static bool SaveNewPermit(string userName, string zip)
        {
            // **********************************************************
            // todo:  get actual existing data base to work with from disk.
            // fakeDB needs to be set to this data base array
            // ************************************************************

            for (int i = 0; i < fakeDB.GetLength(0); i++)
            {
                if (fakeDB[i, 0] == null)  // looking for first empty position. note need to also look for empty string.. ""
                {
                    fakeDB[i, 0] = userName;
                    fakeDB[i, 1] = zip.ToString();  // must convert to string since array is all strings.
                    fakeDB[i, 2] = DateTime.Now.ToShortDateString();

                    // update file on disk with new data here...

                    return true; // success
                } // end if
            }
            return false; //  return false if full
        } // end save new..

        public static string[,] GetPermitsDT()
        {

            return fakeDB;
        }

    } // end class DataModel


}// end namespace


