﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataModelLibrary;

namespace ClassLibraryControler
{
    public class Controler
    {
        //Create middle tier:


        //Validate method, throw exceptions if bad
        //Validate name, at least 4 but not longer than 20 characters
        //Validate zip is at least 5 characters
        // pass good data to data tier with call to SaveNewPermit(username, zip)
        //will return a false if failed to save, then
        // throw exception database full or other database issue

        //public static string[,] GetPermitsMT(string pPW)  // if bad PW throw exception
        // else call data tier to get data and return it
        static public void CheckAndEnterData(string[] elementsToCheck)
        {
            if (elementsToCheck[0].Length < 4 || elementsToCheck[0].Length > 20)
            {
                throw new ApplicationException("Name must be more than 4 and less than 20"); 
            }
            if (elementsToCheck[1].Length!= 5)
            {
                throw new ApplicationException("Zip code must be 5 digits");
            }

            int whoCares;
            bool bResult = Int32.TryParse(elementsToCheck[1], out whoCares); // 'out' means whocares is now defined with the value provided by TryParse.
            if(!bResult) // ie  if false
            {
                throw new ApplicationException("Zip code must be 5 integer digits");
            }
            // after every thing.. save..
            bool bsuccess = DataModel.SaveNewPermit(elementsToCheck[0], elementsToCheck[1]);
        }

        public static string[,] GetPermits(string pW)
        {
            if(pW == "42")
            {
                // get data from data model
                return DataModel.GetPermitsDT();
            }
            else // bad password
            {
                throw new ApplicationException("Invalid Password");
            }
            
        }// end GetPermits

    } // end Controler class

}// end namespace
