﻿using System;

namespace ClassLibrary
{
    // define your delagate here.  The method signature should specify
    //  no return, and 2 required arguements, both of type Pet 
    public delegate void MyPetDelegate(Pet firstPet, Pet secondPet);


    public class Pet : IComparable<Pet>
    {
        public string Name { get; set; }
        public int Weight { get; set; }


        public virtual string GetDescriptionString()
        {
            return "This is from the parent Pet Class";
        }

        // Step [5] AFTER you have your project writing out the string descriptions
        // Come back here and modfy this class to support the 
        // IComparable Interface to support objects of type Pet
        // and write the required method.  The comparison should be based 
        // on the Weight property.
        public int CompareTo(Pet otherPet)
        {
            int nReturnValue = 0;

            if (this.Weight > otherPet.Weight)
            {
                nReturnValue = 1;  // this is bigger suite
            }
            else if (this.Weight < otherPet.Weight)
            {
                nReturnValue = -1; // this is smaller suite
            }
            else // they are the same suite...
            {
                // they are also the same rank
                nReturnValue = 0;
            }// end else same rank

            return nReturnValue;
            //return Weight.CompareTo(obj);
        }// endCompareTo



        // Step [8] AFTER you have your second write out of the 6 pets after they
        // are correctly sorted, come back here and write the required
        // delegate defintion, put it up top in this file where I have the comment, 
        // Then here, write the ModifyNames method that takes in 3 arguements:
        // 2 objects of type Pet, and a method
        // the method is of the data type of the delegate you just defined above
        // this method body is just one line of code, it calls the method
        // that you passed in using the other 2 passed in parameters as its arguements.

        public void ModifyNames(Pet myPet1, Pet myPet2, MyPetDelegate myDelegate)
        {
            myDelegate(myPet1, myPet2);
        }

    }


    //  Step [1] Modify both of these two classes to be children of the Pet class

    //  Step [2] Add constructors to both of them; 

    //  Step [3] and overide the parents GetDescriptionString method
    //  so that it returns a string such as 
    //           My name is Percy and I weigh 45 pounds
    // or 
    //          My name is Jax and I weigh 14 pounds
    // where the Name and Weight properties are used to form the correct string.

    // >>>>>>>>>   DO NOT use a Console.Writeline in this GetDescriptionString!  <<<<<<<<<<<<


    public class Dog : Pet
    {
        //  Step [2]add constructor to set Name and Weight properties
        public Dog(string myName, int myWeight)
        {
            Name = myName;
            Weight = myWeight;
        }


        public override string GetDescriptionString()
        {
            return "My Name is " + Name + " and I weigh " + Weight + " pounds.";
        }

    }// end class Dog




    public class Cat : Pet
    {
        // add constructor to set Name and Weight properties
        public Cat(string myName, int myWeight)
        {
            Name = myName;
            Weight = myWeight;
        }

        public override string GetDescriptionString()
        {
            return "My Name is " + Name + " and I weigh " + Weight + " pounds.";
        }

    }// end class cat

}// end namespace
