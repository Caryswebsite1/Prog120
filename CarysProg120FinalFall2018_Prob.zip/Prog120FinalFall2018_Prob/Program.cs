﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog120FinalFall2018_Prob
{
    class Program
    {
        static void Main(string[] args)
        {
            // these 6 object creations will fail until you make the required changes to the Animal Classes
            Dog dog1 = new Dog("Percy", 45);
            Cat cat1 = new Cat("Riley", 12);
            Cat cat2 = new Cat("Jax", 14);
            Dog dog3 = new Dog("Phantom", 35);
            Cat cat3 = new Cat("Mau", 17);
            Dog dog2 = new Dog("Toby", 55);

            // Step [3] add the 6 animals to a new List

            List<Pet> myPets = new List<Pet>();
            myPets.Add(dog1);
            myPets.Add(cat1);
            myPets.Add(cat2);
            myPets.Add(dog3);
            myPets.Add(cat3);
            myPets.Add(dog2);


            // Step [4] add a foreach  here that writes out the description strings using the child method calls
            foreach(Pet mypet in myPets)
            {
                Console.WriteLine(mypet.GetDescriptionString());
            }


            Console.WriteLine();
            // AFTER you get that working, modify the Pet class to support the required 
            // Interface, which is step 5 so that you can use the List Sort method to sort the List (by Weight)

            // Step [6] then uncomment the next line as Sort should now work
            myPets.Sort();

            Console.WriteLine();


            // Step [7] copy your foreach loop from above and paste it here, 
            // so your program will write out the data a 2nd time, but sorted.
            foreach (Pet mypet in myPets)
            {
                Console.WriteLine(mypet.GetDescriptionString());
            }



            Console.WriteLine();

            // Step [9] now instantiate an object of type Pet  (1 line of code)

            Pet mynewPet = new Pet();

            // Step [10] call the new method of this new object, the method you just wrote in step 8, ModifyNames
            // passing in the objects cat1 and dog1 and the name of a method called SwapNames (not yet defined) (1 line of code)
            //  now go  below and do step [11]

            mynewPet.ModifyNames(cat1, dog1, SwapNames);


            Console.WriteLine();

            // Step [12] copy your foreach loop from above and paste it here again, 
            // so your program will write out the data a 3rd time, 
            // but this time two of the animals, cat1 and dog1, the ones you chose to
            // pass into your ModifyNames method, will have their names swapped.
            foreach (Pet mypet in myPets)
            {
                Console.WriteLine(mypet.GetDescriptionString());
            }

            Console.ReadLine();  // end of Main method

        }// end Main


        // Step [11] here you need to write a static method called SwapNames 
        // that complies with the delegate defination
        // this method should take in two Pet objects, and just swap their Name property values
        // see my program output in the word doc
        private static void SwapNames(Pet firstPet, Pet secondPet)
        {
            // swap names:
            string tempName = "";
            tempName = firstPet.Name;
            firstPet.Name = secondPet.Name;
            secondPet.Name = tempName;
        }

    }// end class program
}// end namespace
