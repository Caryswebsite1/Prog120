﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortFruit
{
    public class Fruit :IComparable<Fruit>
    {

        private int _weight;

        public int weight
        {
            get { return _weight; }
            set { _weight = value; }
        }

        private double _price;

        public double price
        {
            get { return _price; }
            set { _price = value; }
        }

        private String _name;

        public String Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // constructor
        public Fruit(String myName, int myWeight, double myPrice)
        {
            Name = myName;
            weight = myWeight;
            price = myPrice;

        }

        public void print()
        {
            Console.WriteLine(Name + " weight: " + weight + " price: " + price);
        }

        public int CompareTo(Fruit other)
        {
            // compare by weight
            if(this.weight > other.weight)
            {
                // my weight is bigger
                return 1;
            }
            else if( this.weight < other.weight)
            {
                // my weight is less
                return -1;
            }

            // at this point, weights are equal.  now sort by price:
            if (this.price > other.price)
            {
                // my weight is bigger
                return 1;
            }
            else if (this.price < other.price)
            {
                // my weight is less
                return -1;
            }

            // ok at end of everything. all must be equal so just return 0
                return 0;
            
        }// end compare
               
    }// end class Fruit

    public class Apple : Fruit
    {

        Apple(String myName, int myWeight, double myPrice) : base(myName, myWeight, myPrice)
        {
 
        }

    }

    public class Bannana : Fruit
    {
        Bannana(String myName, int myWeight, double myPrice) : base(myName, myWeight, myPrice)
        {

        }

    }


}// end namespace SortFruit
