﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesCompareNames
{
    // this is the delegate declaration.  any delegate method implimentation must match this signature
    public delegate int OurComparer(EmployeeName obj1, EmployeeName obj2);  // notice it is sitting outside of all classes, but in the namespace



    public class EmployeeName // this is a new class we provide that holds names
    {
        // fields
        private string FirstName = null;
        private string LastName = null;

        public EmployeeName(string first, string last)  // constructor
        {
            FirstName = first;
            LastName = last;
        }

        public override string ToString()  // overriding the normal ToString so we have an easy way of writing out the values, we'll use later below
        {
            return FirstName + " " + LastName;
        }

        // This method provides a delegate method that satisfies the Comparer definition
        public static int CompareFirstNames(EmployeeName name1, EmployeeName name2)
        // note it returns an int and takes in 2 objects, so it supports the delegate defintion
        // this one compares just using the built in String compare, so list will be sorted alphabetically  by  first name
        {
            string n1 = (name1).FirstName;
            string n2 = (name2).FirstName;

            return String.Compare(n1, n2);

            //if (String.Compare(n1, n2) > 0)
            //{
            //    return 1;
            //}
            //else if (String.Compare(n1, n2) < 0)
            //{
            //    return -1;
            //}
            //else
            //{
            //    return 0;
            //}
        }// end CompareFirstNames



        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // You need to write a 2nd method
        // This Method needs to provide a different delegate method 
        // note it returns an int and takes in 2 objects, so it supports the delegate defintion
        // this one should compare objects based on the LENGTH of the first and second name combined
        // so for example  Bob Smith is less than Bobby Smitty but equal to Jim Jones

        public static int CompareLengthNames(EmployeeName name1, EmployeeName name2)
        {
            int nLength1 = name1.FirstName.Length + name1.LastName.Length;
            int nLength2 = name2.FirstName.Length + name2.LastName.Length;

            int nCompare = nLength1 - nLength2;

            if (nCompare > 0)
            {
                return 1;
            }
            else if (nCompare < 0)
            {
                return -1;
            }
            else
            {
                return 0;
            }

        }// end CompareLengthNames

        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // You need to write a 3rd method that does a compare based on by the number of vowels in both the first and last name
        // vowels are  a  e  i  o  u
        // you MUST write and use a helper method to count the vowels

        public static int CompareVowels(EmployeeName name1, EmployeeName name2)
        {
            int n1Vowels = VowelCount(name1);
            int n2Vowels = VowelCount(name2);

            int nCompare = n1Vowels - n2Vowels;

            if (nCompare > 0)
            {
                return 1;
            }
            else if (nCompare < 0)
            {
                return -1;
            }
            else
            {
                return 0;
            }

        }// end CompareVowels

        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // VowelCount(EmployeeName EmpName)
        //
        // counts the total number of vowels in a string
        // vowels are  a e  i o  u
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        public static int VowelCount(EmployeeName EmpName)
        {
            int TotVowels = 0;

            string n1 = (EmpName).FirstName + (EmpName).LastName;
            //// using LINQ... 
            //TotVowels = n1.Count(x => x == 'a') + n1.Count(x => x == 'A') +
            //              n1.Count(x => x == 'e') + n1.Count(x => x == 'E') +
            //              n1.Count(x => x == 'i') + n1.Count(x => x == 'I') +
            //              n1.Count(x => x == 'o') + n1.Count(x => x == 'O') +
            //              n1.Count(x => x == 'u') + n1.Count(x => x == 'U');

            // NOTE:  another way would be to make a string of the vowels and contains function on it, passing in the char of the names...
            // basically kind of backwards from what I would normally think.
            // ie: 
            string theVowels = "AaEeIiOoUu";
            int i = 0;
            for (i = 0; i < n1.Length; i++)
            {
                if (theVowels.Contains(n1[i]))
                {
                    TotVowels += 1;
                }
            }// end for


            return TotVowels;
        }// end VowelCount

    }

}
