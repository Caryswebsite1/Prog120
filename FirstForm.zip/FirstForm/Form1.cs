﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirstForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            double dFirstNum = Convert.ToDouble(FirstNumberBox.Text);
            double dSecondNum = Convert.ToDouble(SecondNumberBox.Text);
            double dAnswer = dFirstNum + dSecondNum;

            AnswerBox.Text = dAnswer.ToString();
        }
    }
}
